# UKTRS Aplikacija

Ova aplikacija omogućava unos i izmenu klubova, pregled dugovanja i generisanje faktura.